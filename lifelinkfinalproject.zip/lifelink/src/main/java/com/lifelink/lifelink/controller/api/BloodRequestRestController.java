package com.lifelink.lifelink.controller.api;

import com.lifelink.lifelink.entity.BloodRequest;
import com.lifelink.lifelink.repository.BloodRequestRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/blood-requests")
public class BloodRequestRestController {

    private final BloodRequestRepository bloodRequestRepository;

    public BloodRequestRestController(
            BloodRequestRepository bloodRequestRepository) {
        this.bloodRequestRepository = bloodRequestRepository;
    }

    // Get all blood requests
    @GetMapping
    public List<BloodRequest> getAllBloodRequests() {
        return bloodRequestRepository.findAll();
    }

    // Add a blood request
    @PostMapping
    public BloodRequest addBloodRequest(
            @RequestBody BloodRequest bloodRequest) {

        return bloodRequestRepository.save(bloodRequest);
    }
}