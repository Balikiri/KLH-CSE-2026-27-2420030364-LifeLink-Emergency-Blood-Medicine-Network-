package com.lifelink.lifelink.controller.api;

import com.lifelink.lifelink.entity.Donor;
import com.lifelink.lifelink.repository.DonorRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/donors")
public class DonorRestController {

    private final DonorRepository donorRepository;

    public DonorRestController(DonorRepository donorRepository) {
        this.donorRepository = donorRepository;
    }

    // Get all donors
    @GetMapping
    public List<Donor> getAllDonors() {
        return donorRepository.findAll();
    }

    // Search donors
    @GetMapping("/search")
    public List<Donor> searchDonors(
            @RequestParam(required = false) String bloodGroup,
            @RequestParam(required = false) String location) {

        boolean hasBloodGroup =
                bloodGroup != null && !bloodGroup.trim().isEmpty();

        boolean hasLocation =
                location != null && !location.trim().isEmpty();

        if (hasBloodGroup && hasLocation) {
            return donorRepository.findByBloodGroupAndLocation(
                    bloodGroup.trim(),
                    location.trim()
            );
        }

        if (hasBloodGroup) {
            return donorRepository.findByBloodGroup(
                    bloodGroup.trim()
            );
        }

        if (hasLocation) {
            return donorRepository.findByLocation(
                    location.trim()
            );
        }

        return donorRepository.findAll();
    }

    // Add a donor
    @PostMapping
    public Donor addDonor(@RequestBody Donor donor) {
        return donorRepository.save(donor);
    }
}