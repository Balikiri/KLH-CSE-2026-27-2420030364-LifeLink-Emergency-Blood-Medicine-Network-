package com.lifelink.lifelink.controller.api;

import com.lifelink.lifelink.entity.Medicine;
import com.lifelink.lifelink.repository.MedicineRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/medicines")
public class MedicineRestController {

    private final MedicineRepository medicineRepository;

    public MedicineRestController(MedicineRepository medicineRepository) {
        this.medicineRepository = medicineRepository;
    }

    // Get all medicines
    @GetMapping
    public List<Medicine> getAllMedicines() {
        return medicineRepository.findAll();
    }

    // Search medicines
    @GetMapping("/search")
    public List<Medicine> searchMedicines(
            @RequestParam(required = false) String name,
            @RequestParam(required = false) String location) {

        boolean hasName =
                name != null && !name.trim().isEmpty();

        boolean hasLocation =
                location != null && !location.trim().isEmpty();

        if (hasName && hasLocation) {
            return medicineRepository
                    .findByNameContainingIgnoreCaseAndLocationIgnoreCase(
                            name.trim(),
                            location.trim()
                    );
        }

        if (hasName) {
            return medicineRepository
                    .findByNameContainingIgnoreCase(name.trim());
        }

        if (hasLocation) {
            return medicineRepository
                    .findByLocationIgnoreCase(location.trim());
        }

        return medicineRepository.findAll();
    }

    // Add a medicine
    @PostMapping
    public Medicine addMedicine(@RequestBody Medicine medicine) {
        return medicineRepository.save(medicine);
    }
}