package com.lifelink.lifelink.controller.api;

import com.lifelink.lifelink.entity.Volunteer;
import com.lifelink.lifelink.repository.VolunteerRepository;

import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/volunteers")
public class VolunteerRestController {

    private final VolunteerRepository volunteerRepository;

    public VolunteerRestController(VolunteerRepository volunteerRepository) {
        this.volunteerRepository = volunteerRepository;
    }

    // Get all volunteers
    @GetMapping
    public List<Volunteer> getAllVolunteers() {
        return volunteerRepository.findAll();
    }

    // Search volunteers
    @GetMapping("/search")
    public List<Volunteer> searchVolunteers(
            @RequestParam(required = false) String location,
            @RequestParam(required = false) String availability) {

        boolean hasLocation =
                location != null && !location.trim().isEmpty();

        boolean hasAvailability =
                availability != null && !availability.trim().isEmpty();

        if (hasLocation && hasAvailability) {
            return volunteerRepository
                    .findByLocationAndAvailability(
                            location.trim(),
                            availability.trim()
                    );
        }

        if (hasLocation) {
            return volunteerRepository
                    .findByLocation(location.trim());
        }

        if (hasAvailability) {
            return volunteerRepository
                    .findByAvailability(availability.trim());
        }

        return volunteerRepository.findAll();
    }

    // Add a volunteer
    @PostMapping
    public Volunteer addVolunteer(@RequestBody Volunteer volunteer) {
        return volunteerRepository.save(volunteer);
    }
}